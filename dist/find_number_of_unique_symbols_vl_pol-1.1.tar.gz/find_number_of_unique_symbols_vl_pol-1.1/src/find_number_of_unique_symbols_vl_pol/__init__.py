"""" This script takes a string and returns the number of unique characters in the string
You can use CLI to work with this funcs"""

from find_number_of_unique_symbols_vl_pol.number_of_symbols import find_number_of_unique_symbols, use_func_and_enter_argument_with_console
