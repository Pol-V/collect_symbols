This is a package for counting the quantity of unique symbols in string or list of the strings.
You can use CLI for operating with it. 

