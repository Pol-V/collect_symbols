import argparse


# Imports go here...
from functools import lru_cache


from typing import Callable, Union

# Constants go here...
MAXSIZE_FOR_CACHE = 16


def list_to_tuple(function: Callable):
    """Decorator makes tuple from list if it is an unhashable argument for another function"""
    def wrapper(input_arg: Union[str, list], **kwargs):
        if isinstance(input_arg, list):
            input_arg = tuple(input_arg)
        result = function(input_arg, **kwargs)
        return result
    return wrapper


@list_to_tuple
@lru_cache(maxsize=MAXSIZE_FOR_CACHE)
def find_number_of_unique_symbols(input_string):
    """Function returns number of unique symbols in string if argument is a string. Or list of numbers if argument is a list of strings"""
    try:
        if type(input_string) == str:
            res = len([symbol for symbol in input_string if input_string.count(symbol) == 1])
        elif type(input_string) == tuple and all(type(strings) == str for strings in input_string):
            res = list(map(lambda string: len([symbol for symbol in string if string.count(symbol) == 1]), input_string))
        else:
            raise TypeError('Please use just strings or list of strings')
        return res
    except TypeError:
        raise TypeError('Please use just strings or list of strings')



def use_func_and_enter_argument_with_console(inp_object):
    if isinstance(inp_object, (str, list)):
        return find_number_of_unique_symbols(inp_object)
    else:
        with open(inp_object, 'r') as f:
            result = f.read().split('\n')
            return find_number_of_unique_symbols(result)




if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('-s', '--string', help='Your string', type=str)
    parser.add_argument('-f', '--file', help='Your file')
    args = parser.parse_args()

    if args.string and args.file:
        with open(args.file, 'r') as file_data:
            file_data = file_data.read().split('\n')
            print(use_func_and_enter_argument_with_console(file_data))
    elif args.string:
        print(use_func_and_enter_argument_with_console(args.string))
    elif args.file:
        with open(args.file, 'r') as file_data:
            file_data = file_data.read().split('\n')
            print(use_func_and_enter_argument_with_console(file_data))







